// code try 1
// divs are getting dragged & dropped from one container to other but not in same container
// also droppedItems are getting dragged & dropped anywhere within same container but not in other
// the new items are getting dragged & dropped anywhere in other container
//only new items are sortable

$(document).ready(function(){
    $('.upper-div').sortable();
    $('.lower-div').sortable();


    $('.draggable-div-lower').draggable({helper:'clone'});
    $('.upper-div').droppable({
        accept:'.draggable-div-lower',
        drop:function(ev,ui){
            
            var droppedItem = $(ui.draggable).clone();
            $(this).append(droppedItem);
        }
    });



    $('.draggable-div-upper').draggable({helper:'clone'});
    $('droppedItem').draggable({helper:'clone'});
    $('.lower-div').droppable({
        accept:'.draggable-div-upper',
        drop:function(ev,ui){
            
            var droppedItem = $(ui.draggable).clone();
            $(this).append(droppedItem);
        }
    });
    
    $('#add-to-upper').click(function(){
        $('.upper-div').append("<div class=\"draggable-div-upper\"> New Item </div>");
    });

    $('#add-to-lower').click(function(){
        $('.lower-div').append("<div class=\"draggable-div-lower\"> New Item </div>");
    });
});





// code try 2
// divs are getting copied in their own container as well as to other container
// droppedItems are draggable & droppable anywhere on the document
// new items are draggable but not droppable



/* $(document).ready(function(){
    $('.upper-div').sortable();
    $('.lower-div').sortable();


    $('.list-item').draggable({helper:'clone'});
    $('.upper-div').droppable({
        accept:'.list-item',
        drop:function(ev,ui){
            
            var droppedItem = $(ui.draggable).clone();
            $(this).append(droppedItem);
        }
    });



    $('.list-item').draggable({helper:'clone'});
    $('droppedItem').draggable({helper:'clone'});
    $('.lower-div').droppable({
        accept:'.list-item',
        drop:function(ev,ui){
            
            var droppedItem = $(ui.draggable).clone();
            $(this).append(droppedItem);
        }
    });
    
    $('#add-to-upper').click(function(){
        $('.upper-div').append("<div class=\"draggable-div-upper\"> New Item </div>");
    });

    $('#add-to-lower').click(function(){
        $('.lower-div').append("<div class=\"draggable-div-lower\"> New Item </div>");
    });
}); */